<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>TechCraftery Billing System</title>
</head>
<body>
<div class="fl-row fl-row-full-width fl-row-bg-color fl-node-yx7blenq60kv fl-row-default-height fl-row-align-center" data-node="yx7blenq60kv">
  <div class="fl-row-content-wrap">
    <div class="uabb-row-separator uabb-top-row-separator">
</div>
            <div class="fl-row-content fl-row-fixed-width fl-node-content">
    
<div class="fl-col-group fl-node-k7g9lcjas6fv" data-node="k7g9lcjas6fv">
      <div class="fl-col fl-node-29ephjlu74dv" data-node="29ephjlu74dv">
  <div class="fl-col-content fl-node-content"><div class="fl-module fl-module-rich-text fl-node-brzliqe38hmy" data-node="brzliqe38hmy">
  <div class="fl-module-content fl-node-content">
    <div class="fl-rich-text">
  <p style="text-align: center; bottom: 0;">© 2024 Techcraftery. All Rights Reserved.</p>
</div>
  </div>
</div>
</div>
</div>
  </div>
    </div>
  </div>
</div>
</body>
</html>